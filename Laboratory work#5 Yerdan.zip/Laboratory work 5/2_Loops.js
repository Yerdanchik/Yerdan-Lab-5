'use strict';

process.stdin.resume();
process.stdin.setEncoding('utf-8');

let inputString = '';
let currentLine = 0;

process.stdin.on('data', inputStdin => {
    inputString += inputStdin;
});

process.stdin.on('end', _ => {
    inputString = inputString.trim().split('\n').map(string => {
        return string.trim();
    });
    
    main();    
});

function readLine() {
    return inputString[currentLine++];
}

function vowelsAndConsonants(s) {
    let v = [], c = [];
    
for(let i = 0; i < s.length; i++){
    let char = s.charAt(i);
    if(char == 'a' || char == 'e'|| char == 'i' ||
    char == 'o' || char == 'u' ){v += char }
    else{c += char}
}
for(let y = 0; y < v.length; y++){console.log(v.charAt(y));}
for(let x = 0; x < c.length; x++){console.log(c.charAt(x));}
}

