var count = 0;
function Click(el) {
    count++;
    el.innerHTML = count; 
  }